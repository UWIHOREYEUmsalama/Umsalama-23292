package testCases;

import dao.StudentRegistrationDao;
import java.util.List;
import model.Course;
import model.Semester;
import model.Student;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class StudentsByCourse_Semester {

	private StudentRegistrationDao studentDao;

	public StudentsByCourse_Semester() {
	}

	@Before
	public void setUp() {
		this.studentDao = new StudentRegistrationDao();
	}

	@Test
	public void testGetStudentsByCourseAndSemester() {
		Course course = new Course();
		course.setCourseCode("COSC 5054");
		Semester semester = new Semester();
		semester.setSemId("3");
		List<Student> students = this.studentDao.getStudentsByCourseAndSemester(course, semester);
		Assert.assertThat(students, CoreMatchers.is(CoreMatchers.not(CoreMatchers.nullValue())));
	 }
}
