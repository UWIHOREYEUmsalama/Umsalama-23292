package testCases;

import dao.StudentRegistrationDao;
import java.util.List;
import model.AcademicUnit;
import model.Course;
import model.Semester;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CoursesByDepartmentAndBySemester {

	private StudentRegistrationDao courseDao;

	public CoursesByDepartmentAndBySemester() {
	}

	@Before
	public void setUp() {
		this.courseDao = new StudentRegistrationDao();
	}

	@Test
	public void testGetCoursesByDepartmentAndSemester() {
		AcademicUnit department = new AcademicUnit();
		department.setUnitCode("1");
		Semester semester = new Semester();
		semester.setSemId("089");
		List<Course> courses = this.courseDao.getCoursesByDepartmentAndSemester(department, semester);
		Assert.assertThat(courses, CoreMatchers.is(CoreMatchers.not(CoreMatchers.nullValue())));
		 }
}
